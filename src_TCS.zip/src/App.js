import './App.css';
import Header from './Header/Header';
import Table from './Table/Table';

function App() {
  return (
    <div>
      <Header />

      <p className='TabTitle'>Rule set Authoring</p>

      <div className='PaginationContainer'>
        <label className='PageInputLabel'>Records per page: </label>
        <input className='PageInput' />
        <p>
          Showing <span className='PageCount'>1-20/39</span>
        </p>
        <div className='Pagination'>
          <p>First</p>
          <p>Prev</p>
          <p>1</p>
          <p>2</p>
          <p>Next</p>
          <p>Last</p>
        </div>
      </div>
      <Table />
    </div>
  );
}

export default App;

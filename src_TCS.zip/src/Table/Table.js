import React from 'react';
import { TableHeadings, TableData } from './TableData';
import './Table.css';

const Table = () => {
  return (
    <div className='TableContainer'>
      <table className='Table'>
        <tr>
          {TableHeadings.map((item) => (
            <th>{item}</th>
          ))}
        </tr>
        <tr>
          <td className='TDWidth'>
            <input className='InputBox' type='text' />
          </td>
          <td>
            <input className='InputBox' type='text' />
          </td>
          <td>
            <input className='InputBox' type='text' />
          </td>
          <td>
            <select name='' className='InputBox'>
              <option>Select...</option>
            </select>
          </td>
          <td>
            <select name='Active' className='InputBox'>
              <option>Choose...</option>
              <option>Active</option>
              <option>Inactive</option>
            </select>
          </td>
          <td>
            <p className='CreateRuleSetButton'>Create Rule Set</p>
          </td>
        </tr>

        {TableData.map((item) => (
          <tr>
            <td className='TableContent'>{item.Name}</td>
            <td className='TableContent'>{item.Description}</td>
            <td className='TableContent'>{item.Tags}</td>
            <td className='TableContent'>{item.CreatedBy}</td>
            <td className='TableContent'>{item.Active}</td>
            <td className='TableContent'>{item.Actions}</td>
          </tr>
        ))}
      </table>
    </div>
  );
};

export default Table;
